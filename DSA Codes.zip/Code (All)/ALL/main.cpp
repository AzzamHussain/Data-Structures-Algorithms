#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;



int main()
{
   int my2DArray[2][2] = {{1, 2}, {4, 5}};
   cout << sizeof(my2DArray);
}