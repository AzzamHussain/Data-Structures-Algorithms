#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student
{
    int ID;
    struct Student* sNext;
};

struct Course
{
    int cCode;
    struct Student* sStart;
    char cName[50];
    struct Course* cNext;
};

struct Course* cStart = NULL;

void insertCourse()
{
    int newCode;
    printf("Enter code of the course: ");
    scanf("%d", &newCode);

    struct Course* curr = cStart;
    while (curr != NULL)
    {
        if (curr->cCode == 0)
        {
            printf("It is an invalid code.\n");
            return;
        }
        else if (curr->cCode == newCode)
        {
            printf("Following code already exists.\n");
            return;
        }
        curr = curr->cNext;
    }

    fflush(stdin);
    char cName[50];
    printf("Enter Name of the course: ");
    scanf("%49s", cName);

    struct Course* temp = (struct Course*)malloc(sizeof(struct Course));
    temp->cCode = newCode;
    strcpy(temp->cName, cName);
    temp->cNext = NULL;
    temp->sStart = NULL;

    if (cStart == NULL)
    {
        cStart = temp;
    }
    else
    {
        curr = cStart;
        while (curr->cNext != NULL)
        {
            curr = curr->cNext;
        }
        curr->cNext = temp;
    }
}

void insertStudent()
{
    int ID;
    int courseID;
    printf("Enter ID of the student: ");
    scanf("%d", &ID);
    printf("Enter code of the course, student wants to enroll in: ");
    scanf("%d", &courseID);

    struct Course* cCurr = cStart;

    while (cCurr != NULL)
    {
        if (cCurr->cCode == courseID)
        {
            struct Student* sCurr = cCurr->sStart;
            while (sCurr != NULL)
            {
                if (sCurr->ID == ID)
                {
                    printf("Student is already enrolled in this course!\n");
                    return;
                }
                sCurr = sCurr->sNext;
            }

            struct Student* temp = (struct Student*)malloc(sizeof(struct Student));
            temp->ID = ID;
            temp->sNext = NULL;

            if (cCurr->sStart == NULL)
            {
                cCurr->sStart = temp;
            }
            else
            {
                sCurr = cCurr->sStart;
                while (sCurr->sNext != NULL)
                {
                    sCurr = sCurr->sNext;
                }
                sCurr->sNext = temp;
            }
            return;
        }
        cCurr = cCurr->cNext;
    }
    printf("Following course does not exist.\n");
}

void deleteStudentCourse()
{
    struct Course* cCurr = cStart;
    int toDelete;
    int cCode;
    printf("Enter code of the course, student is enrolled in: ");
    scanf("%d", &cCode);

    while (cCurr != NULL)
    {
        if (cCode != cCurr->cCode)
        {
            cCurr = cCurr->cNext;
        }
        else
        {
            break;
        }
    }

    if (cCurr == NULL)
    {
        printf("Following course does not exist.\n");
        return;
    }

    printf("Enter ID of the student to delete: ");
    scanf("%d", &toDelete);

    struct Student* sCurr = cCurr->sStart;
    struct Student* sPrev = NULL;

    while (sCurr != NULL)
    {
        if (sCurr->ID == toDelete)
        {
            if (sPrev == NULL)
            {
                cCurr->sStart = sCurr->sNext;
                free(sCurr);
            }
            else
            {
                sPrev->sNext = sCurr->sNext;
                free(sCurr);
            }
            printf("ID %d is deleted.\n", toDelete);
            return;
        }
        sPrev = sCurr;
        sCurr = sCurr->sNext;
    }
    printf("Following student is not enrolled in this course.\n");
    return;
}

void Print()
{
    if (cStart == NULL)
    {
        printf("No Courses!!\n");
        return;
    }

    struct Course* cCurr = cStart;
    while (cCurr != NULL)
    {
        printf("Course Name: %s\n", cCurr->cName);
        printf("Course code: %d\n", cCurr->cCode);
        struct Student* sCurr = cCurr->sStart;

        if (sCurr == NULL)
        {
            printf("There are currently no students enrolled in this course.\n");
        }
        else if (sCurr != NULL)
        {
            printf("Students enrolled in the course are:\n");
        }

        while (sCurr != NULL)
        {
            printf("%d\n", sCurr->ID);
            sCurr = sCurr->sNext;
        }
        printf("\n");
        cCurr = cCurr->cNext;
    }
}

void search()
{
    int studentFound = 0;
    printf("Enter ID of the student to search: ");
    int toSearch;
    scanf("%d", &toSearch);
    struct Course* cCurr = cStart;
    printf("The student is enrolled in the following courses:\n");
    while (cCurr != NULL)
    {
        struct Student* sCurr = cCurr->sStart;
        while (sCurr != NULL)
        {
            if (sCurr->ID == toSearch)
            {
                printf("%d\n", cCurr->cCode);
                studentFound = 1;
            }
            sCurr = sCurr->sNext;
        }
        cCurr = cCurr->cNext;
    }
    if (studentFound == 0)
    {
        printf("Following student is not enrolled in any course.\n");
    }
}

void deletion()
{
    int studentFound = 0;
    printf("Enter ID of the student to delete: ");
    int toDelete;
    scanf("%d", &toDelete);
    struct Course* cCurr = cStart;
    while (cCurr != NULL)
    {
        struct Student* sCurr = cCurr->sStart;
        struct Student* sPrev = NULL;
        while (sCurr != NULL)
        {
            if (sCurr->ID == toDelete)
            {
                if (sPrev == NULL)
                {
                    cCurr->sStart = sCurr->sNext;
                }
                else
                {
                    sPrev->sNext = sCurr->sNext;
                }
                free(sCurr);
                studentFound = 1;
                break;
            }
            sPrev = sCurr;
            sCurr = sCurr->sNext;
        }
        cCurr = cCurr->cNext;
    }
    if (studentFound == 0)
    {
        printf("Following student is not enrolled in any course.\n");
    }
}

void deleteACourse()
{
    printf("Enter code of the course you want to delete: ");
    int toDelete;
    scanf("%d", &toDelete);
    struct Course* cCurr = cStart;
    struct Student* sCurr = NULL;
    struct Course* prev = NULL;

    while (cCurr != NULL)
    {
        if (cCurr->cCode == toDelete)
        {
            while (cCurr->sStart != NULL)
            {
                sCurr = cCurr->sStart;
                struct Student* temp = sCurr;
                cCurr->sStart = sCurr->sNext;
                free(temp);
            }
            if (prev == NULL)
            {
                cStart = cCurr->cNext;
            }
            else
            {
                prev->cNext = cCurr->cNext;
            }
            free(cCurr);
            printf("Course %d is deleted.\n", toDelete);
            return;
        }
        prev = cCurr;
        cCurr = cCurr->cNext;
    }
}

int main()
{
    int opt;
    printf("\t 1: Enter a course. \n");
    printf("\t 2: Enroll a student to a course. \n");
    printf("\t 3: Delete a student from a course. \n");
    printf("\t 4: Print. \n");
    printf("\t 5: Search for a student. \n");
    printf("\t 6: Delete a student from all courses. \n");
    printf("\t 7: Delete a course. \n");
    printf("\t 0: Exit. \n");
    scanf("%d", &opt);

    while (opt != 0)
    {
        switch (opt)
        {
            case 1:
                insertCourse();
                break;
            case 2:
                insertStudent();
                break;
            case 3:
                deleteStudentCourse();
                break;
            case 4:
                Print();
                break;
            case 5:
                search();
                break;
            case 6:
                deletion();
                break;
            case 7:
                deleteACourse();
                break;
            default:
                printf("Invalid option.\n");
                break;
        }
        printf("\t 1: Enter a course. \n");
        printf("\t 2: Enroll a student to a course. \n");
        printf("\t 3: Delete a student from a course. \n");
        printf("\t 4: Print. \n");
        printf("\t 5: Search for a student. \n");
        printf("\t 6: Delete a student from all courses. \n");
        printf("\t 7: Delete a course. \n");
        printf("\t 0: Exit. \n");
        scanf("%d", &opt);
    }

    // Free allocated memory before exiting
    struct Course* currCourse = cStart;
    while (currCourse != NULL)
    {
        struct Student* currStudent = currCourse->sStart;
        while (currStudent != NULL)
        {
            struct Student* temp = currStudent;
            currStudent = currStudent->sNext;
            free(temp);
        }
        struct Course* tempCourse = currCourse;
        currCourse = currCourse->cNext;
        free(tempCourse);
    }

    return 0;
}

