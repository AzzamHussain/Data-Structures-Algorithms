#include <stdio.h>
#include <stdlib.h>

// Node structure for the linked list
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Function to create a new node
Node* newNode(int data) {
    Node* temp = (Node*)malloc(sizeof(Node));
    temp->data = data;
    temp->next = NULL;
    return temp;
}

// Function to insert a new node into the linked list in sorted order
void sortedInsert(Node** head, int data) {
    Node* new_node = newNode(data);
    if (*head == NULL || (*head)->data >= new_node->data) {
        // If the list is empty or new data is smaller than the head, insert at the beginning
        new_node->next = *head;
        *head = new_node;
    } else {
        // Traverse the list to find the right position for insertion
        Node* current = *head;
        while (current->next != NULL && current->next->data < new_node->data) {
            current = current->next;
        }
        // Insert the new node into the correct position
        new_node->next = current->next;
        current->next = new_node;
    }
}

// Function to calculate the median of the linked list
float getMedian(Node* head, int count) {
    if (!head) return 0;

    Node* current = head;
    if (count % 2 != 0) {
        // If the count is odd, find the middle element
        int i = 0;
        while (i < count / 2) {
            current = current->next;
            i++;
        }
        return current->data;
    } else {
        // If the count is even, find the two middle elements and calculate their average
        int i = 0;
        while (i < (count / 2) - 1) {
            current = current->next;
            i++;
        }
        return (current->data + current->next->data) / 2.0;
    }
}

// Function to free the memory occupied by the linked list
void freeList(Node* head) {
    while (head != NULL) {
        Node* temp = head;
        head = head->next;
        free(temp);
    }
}

int main() {
    FILE* file;
    file = fopen("Test02.txt", "r");

    if (file == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    Node* head = NULL;
    int num, count = 0;

    while (fscanf(file, "%d", &num) != EOF) {
        // Insert the new number into the linked list and increment the count
        sortedInsert(&head, num);
        count++;
        // Calculate and print the current median
        printf("%d Median : %0.1f\n", num, getMedian(head, count));
    }

    fclose(file);
    // Free the memory occupied by the linked list
    freeList(head);

    return 0;
}

