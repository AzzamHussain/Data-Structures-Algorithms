#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a structure for a doubly linked list node
struct Node {
    int ID;
    struct Node* next;
    struct Node* previous;
};

// Global variables for the doubly linked list
struct Node* start = NULL; // Start of the list
struct Node* End = NULL;   // End of the list
struct Node* cursor = NULL; // Cursor for navigation
int counter = 0;           // Count of elements in the list
int cursorcount = 0;       // Cursor position
int check = 0;             // Flag for undo operations
int checksub = 0;          // Flag for sub-functions

//---------------------STACK--------------------

// Define a structure for a stack to store operation details
struct Data {
    int code;   // Operation code
    int index;  // Index for the operation
    int value;  // Value related to the operation
    struct Data* next;
};

// Global variable for the stack
struct Data* top = NULL;

// Function to push an operation onto the stack
void push(int code, int index, int ID) {
    struct Data* temp = (struct Data*)malloc(sizeof(struct Data));
    temp->code = code;
    temp->index = index;
    temp->value = ID;
    if (top == NULL) {
        top = temp;
        top->next = NULL;
    }
    else {
        temp->next = top;
        top = temp;
    }
}

// Function to pop an operation from the stack
void pop() {
    struct Data* current = top;
    top = top->next;
    free(current);
}

// Function to print the stack (for debugging)
void pr() {
    struct Data* curr = top;
    while (curr != NULL) {
        printf("code is %d\n", curr->code);
        printf("index is %d\n", curr->index);
        printf("value is %d\n", curr->value);
        curr = curr->next;
    }
}

//----------------------------STACK END

// Following are sub-functions for manipulating the linked list

// Add a node at the start of the list
void ADDatstart(struct Node* temp) { 
    struct Node* curr = start;
    temp->next = curr;
    curr->previous = temp;
    start = temp;
}

// Add a node at a given index in the list
void ADDatmid(struct Node* prev, struct Node* temp) {
    prev->next->previous = temp;
    temp->previous = prev;
    temp->next = prev->next;
    prev->next = temp;
}

// Add a node at the end of the list
void ADDatEnd(struct Node* temp) {  
    struct Node* current = start;
    while (current->next != NULL) {
        current = current->next;
    }
    current->next = temp;
    temp->previous = current;
    End = temp;
}

// Delete the first node in the list
void Deleteatstart() {  
    struct Node* current = start;
    start = start->next;
    if (start != NULL)
        start->previous = NULL;
    free(current);
}

// Delete a node at a given index in the list
void Deleteatmid(struct Node* current) {
    current->previous->next = current->next;
    current->next->previous = current->previous;
    free(current);
}

// Delete the last node in the list
void DeleteatEnd() {        
    struct Node* current = End;
    End = End->previous;
    End->next = NULL;
    free(current);
}

// Function to add a node at the end of the list
void ADD(int b) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
    temp->ID = b;
    temp->next = NULL;
    counter++;
    if (start == NULL) {
        start = temp;
        End = temp;
        start->previous = NULL;
        cursor = start;
    }
    else {
        ADDatEnd(temp);
    }
    if (check == 0) push(1, counter - 1, temp->ID); // Push the operation onto the stack
}

// Function to print the elements of the list
void printt() {
    struct Node* ptr = start;
    if (ptr == NULL) printf("empty\n");
    while (ptr != NULL) {
        printf("%d, ", ptr->ID);
        ptr = ptr->next;
    }
    printf("\n");
}

// Function to print the elements of the list in reverse order
void printreverse() {
    if (start == NULL) {
        printf("list is empty\n");
        return;
    }
    struct Node* end = start;
    while (end->next != NULL) {
        end = end->next;
    }
    while (end != NULL) {
        printf("%d\n", end->ID);
        end = end->previous;
    }
}

// Function to add a node at a specific index in the list
void ADDatIndex(int index, int ID) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
    temp->ID = ID;
    temp->next = NULL;
    temp->previous = NULL;
    if (index > counter || index < 0) {
        printf("Error, wrong index\n");
        return;
    }
    counter++;
    if (index == 0) {               
        ADDatstart(temp);
    }
    else {
        struct Node* prev = start;
        for (int i = 0; i < index - 1; i++) {
            prev = prev->next;
        }
        if (prev->next == NULL) {          
            ADDatEnd(temp);
        }
        else {
            ADDatmid(prev, temp);
        }
    }
    if (index <= cursorcount) {
        cursor = cursor->previous;
    }
    if (check == 0 && checksub == 0) push(2, index, temp->ID); // Push the operation onto the stack
}

// Function to delete the last node in the list
void Delete() {
    if (start == NULL) return;
    printf("%d\n", cursorcount);
    counter--;
    if (cursorcount > counter) {
        cursor = cursor->previous;
        cursorcount -= cursorcount;
    }
    if (check == 0) push(3, counter - 1, End->ID); // Push the operation onto the stack
    if (End == start) {
        struct Node* current = start;
        start = NULL;
        End = NULL;
        free(current);
    }
    else {
        DeleteatEnd();
    }
}

// Function to delete a node at a specific index in the list
void DeleteIndex(int index) {
    int hold;
    if (start == NULL) {
        printf("list is empty\n");
        return;
    }
    if (index >= counter || index < 0) {
        printf("Error, wrong index\n");
        return;
    }
    if (index <= cursorcount && cursor->next != NULL) {
        cursor = cursor->next;
    }
    counter--;
    if (index == 0) {
        hold = start->ID;
        Deleteatstart();
    }
    else {
        struct Node* current = start;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        if (current->next == NULL) {
            hold = current->ID;
            DeleteatEnd();
        }
        else {
            hold = current->ID;
            Deleteatmid(current);
        }
    }
    if (check == 0) push(4, index, hold); // Push the operation onto the stack
}

// Function to undo the last operation
void Undo() {
    if (top == NULL) {
        printf("No operation to undo\n");
        return;
    }
    int code = top->code;
    int index = top->index;
    int value = top->value;
    pop(); // Pop the operation from the stack
    check = 1; // Set the check flag to 1 to avoid pushing undo operation onto the stack
    switch (code) {
        case 1: // Undo an ADD operation
            DeleteIndex(index); // Delete the added node at the specified index
            break;
        case 2: // Undo an ADDatIndex operation
            DeleteIndex(index); // Delete the added node at the specified index
            break;
        case 3: // Undo a Delete operation
            ADD(value); // Add the deleted node back to the list
            break;
        case 4: // Undo a DeleteIndex operation
            ADDatIndex(index, value); // Add the deleted node back to the list at the specified index
            break;
    }
    check = 0; // Reset the check flag
}

int main() {
    int a, b;
    int choice;
    while (1) {
        printf("1.ADD at End\n");
        printf("2.ADD at Index\n");
        printf("3.Delete at End\n");
        printf("4.Delete at Index\n");
        printf("5.Print\n");
        printf("6.Print in Reverse\n");
        printf("7.Undo\n");
        printf("8.Exit\n");
        printf("Enter the choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter the value to be inserted: ");
                scanf("%d", &b);
                ADD(b);
                cursorcount++;
                break;
            case 2:
                printf("Enter the index where you want to add: ");
                scanf("%d", &a);
                printf("Enter the value to be inserted: ");
                scanf("%d", &b);
                ADDatIndex(a, b);
                cursorcount++;
                break;
            case 3:
                Delete();
                cursorcount--;
                break;
            case 4:
                printf("Enter the index where you want to delete: ");
                scanf("%d", &a);
                DeleteIndex(a);
                cursorcount--;
                break;
            case 5:
                printt();
                break;
            case 6:
                printreverse();
                break;
            case 7:
                Undo();
                cursorcount--;
                break;
            case 8:
                exit(0);
        }
    }
    return 0;
}

