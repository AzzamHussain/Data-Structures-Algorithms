#include <stdio.h>
#include <stdlib.h>

// Define a structure for the linked list node.
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Function to create a new node with the given data.
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to add a new node with the given data to the end of the linked list.
void addNode(Node** head, int data) {
    Node* temp = *head;
    Node* newNode = createNode(data);

    // If the list is empty, set the new node as the head.
    if (!(*head)) {
        *head = newNode;
        return;
    }

    // Traverse to the end of the list and append the new node.
    while (temp->next) {
        temp = temp->next;
    }
    temp->next = newNode;
}

// Function to delete the last node from the linked list.
void deleteNode(Node** head) {
    if (!(*head)) return;

    // If there's only one node, free it and set the head to NULL.
    if (!(*head)->next) {
        free(*head);
        *head = NULL;
        return;
    }

    // Traverse to the second-to-last node and free the last node.
    Node* prev = NULL;
    Node* temp = *head;
    while (temp->next) {
        prev = temp;
        temp = temp->next;
    }
    free(temp);
    prev->next = NULL;
}

// Function to find and print the lucky winner(s).
void getTrump(Node* head) {
    if (!head) {
        printf("No customers.\n");
        return;
    }

    Node* slow = head;
    Node* fast = head;
    Node* prevSlow = NULL;

    // Use the slow and fast pointer technique to find the middle or middle two elements.
    while (fast && fast->next) {
        prevSlow = slow;
        slow = slow->next;
        fast = fast->next->next;
    }

    // Print the lucky winner(s) based on the count of customers.
    if (!fast) {
        printf("Lucky Winners: %d and %d\n", prevSlow->data, slow->data);
    } else {
        printf("Lucky Winner: %d\n", slow->data);
    }
}

int main() {
    // Open the input file for reading.
    FILE* file = fopen("Test01.txt", "r");
    if (!file) {
        printf("Error opening the file!\n");
        return 1;
    }

    Node* head = NULL;
    char command[10];
    int number;

    // Read and process commands from the input file.
    while (fscanf(file, "%s", command) != EOF) {
        if (strcmp(command, "ADD") == 0) {
            fscanf(file, "%d", &number);
            addNode(&head, number);
        } else if (strcmp(command, "DELETE") == 0) {
            deleteNode(&head);
        } else if (strcmp(command, "END") == 0) {
            break;
        }
    }

    // Close the input file.
    fclose(file);

    // Find and print the lucky winner(s).
    getTrump(head);

    // Free memory by traversing the linked list and releasing each node.
    while (head) {
        Node* temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}

