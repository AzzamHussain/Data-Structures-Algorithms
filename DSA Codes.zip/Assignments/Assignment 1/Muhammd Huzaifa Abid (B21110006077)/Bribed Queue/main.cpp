#include <stdio.h>

//Function to count the number of bribes in the queue
//n = size of the queue (array)
int BribedQueue(int n, int queue[]) {  
    int bribes = 0; 
    int i;
    for (i = 1; i < n; i++) {
        int key = queue[i];
        int j = i - 1;
        while (j >= 0 && key < queue[j]) {
            queue[j + 1] = queue[j];
            bribes++;
            --j;
        }
        queue[j + 1] = key;
    }
    return bribes;                                   
}

int main(){
    FILE *file;
    int lenght, i;
    
    //Open the file int read mode
    file = fopen("TestCase_01.txt", "r");
	   
    if (file == NULL) {                         
        printf("Elements were not found.\nCheck the text file, as it could be empty or the name of the text file may be incorrectly typed.");
        return 1;                              
    }

	//Read the lenght of the queue
    fscanf(file, "%d", &lenght);                 

    int array[lenght];
    
    //Read the elements of the queue from the text file
    for (i = 0; i < lenght; i++) {
        fscanf(file, "%d,", &array[i]);         
    }
    
    //Close the file
    fclose(file);                           

	//Calling the BribedQueue function
    int num_bribes = BribedQueue(lenght, array);   
	   
    printf("Number of bribes: %d\n", num_bribes); 

    return 0;
}

