#include <stdio.h>

// Function to find the index of a number in an array
int findIndex(int arr[], int size, int num) {
    int left = 0;
    int right = size - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == num)
            return mid;
        else if (arr[mid] < num)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1; // Will return -1 when the number is not found
}

int main() {
    FILE *file;
    file = fopen("TestCase_01.txt", "r");
    
    if (file == NULL) {
        printf("Elements were not found.\nCheck the text file, as it could be empty or the name of the text file may be incorrectly typed.");
        return 1;
    }

    int numToFind, size;
    fscanf(file, "%d", &numToFind);
    fscanf(file, "%d", &size);

    int array[size]; 
    int i;
    for (i = 0; i < size; i++) {
        fscanf(file, "%d,", &array[i]);
    }

    fclose(file);

    // Finding the index of the number in the array
    int result = findIndex(array, size, numToFind);

    if (result == -1) {
        printf("%d does not exist, so -1 will be the answer.\n", numToFind);
    } else {
        printf("%d is at %dth index.\n", numToFind, result);
    }

    return 0;
}

