#include <stdio.h>

//Function to find the highest number of consecutive extended working hours
int GoingOffTheCharts(int arr[], int n) {           
    int maxConsecutive = 0;
    int Consecutive = 0;
    int i;
    
    for (i = 0; i < n; i++) {
        if (arr[i] > 6) {
            Consecutive++;
            if (Consecutive > maxConsecutive) {
                maxConsecutive = Consecutive;
            }
        } 
		else {
            Consecutive = 0;
        }
    }

    return maxConsecutive;                                               
}

int main() {
	
	FILE *file;
    int length, i;
    
    //Read input from the text file
    file = fopen("TestCase_01.txt", "r");                                          
    if (file == NULL) {                                                             
        printf("Elements were not found.\nCheck the text file, as it could be empty or the name of the text file may be incorrectly typed.");
        return 1;                                                                
    }
    
    fscanf(file, "%d", &length);   
	                                                 
    int array[length];
    for (i = 0; i < length; i++) {
        fscanf(file, "%d,", &array[i]);                                            
    }
    
    fclose(file);                                                           

	//Calling the function GoingOffTheCharts
    int extended_Hours = GoingOffTheCharts(array, length);
	                                  
    printf("Highest consecutive extended working hours: %d\n", extended_Hours);        
	return 0;
}
