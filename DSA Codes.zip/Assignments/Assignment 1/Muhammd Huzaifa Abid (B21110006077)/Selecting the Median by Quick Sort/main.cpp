#include <stdio.h>

// Function to swap two elements in an array
void swap(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

// Function to divide the array around a pivot element
int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return i + 1;
}

// Function to perform QuickSort on the array
void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Function to find the median of the array
int selectingTheMedian(int arr[], int size) {
    quickSort(arr, 0, size - 1);
    return arr[size / 2];
}

int main() {
    FILE *file;
    int n;

    // Open the file in read mode
    file = fopen("TestCase_01.txt", "r");

    if (file == NULL) {
        printf("Elements were not found.\nCheck the text file, as it could be empty or the name of the text file may be incorrectly typed.");
        return 1;
    }

    // Read the number of elements in the array
    fscanf(file, "%d", &n);

    int marks[n]; // Assuming a maximum size of 100 for the array

    // Read the elements of the array
    int i;
    for (i = 0; i < n; i++) {
        fscanf(file, "%d,", &marks[i]);
    }

    // Close the file
    fclose(file);

    // Calling the median function
    int median = selectingTheMedian(marks, n);
    printf("Median: %d\n", median);

    return 0;
}

