#include <stdio.h>
#include <stdlib.h>

// Function to perform the insertion sort
void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

// Function to find the median of the array
int SelectingTheMedian(int arr[], int size) {
    insertionSort(arr, size);
    return arr[size / 2];
}

int main() {
    FILE *file;
    int numberToFind, arraySize;

    file = fopen("TestCase_01.txt", "r");
    if (file == NULL) {
        printf("Failed to open the file.\n");
        return 1;
    }

    fscanf(file, "%d", &arraySize);
	
	int array[arraySize];
    for (int i = 0; i < arraySize; i++) {
        fscanf(file, "%d,", &array[i]);
    }

    fclose(file);

    int median = SelectingTheMedian(array, arraySize);
    printf("Median: %d\n", median);

    return 0;
}

