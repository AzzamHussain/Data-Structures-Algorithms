#include <stdio.h>
#include <stdlib.h>

// Function to swap two elements in an array
	swap(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

// Function to divide the array around a pivot element
int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return i + 1;
}

// Function to perform QuickSort on the array
	quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Function to find the median of the array
int SelectingTheMedian(int arr[], int size) {
    quickSort(arr, 0, size - 1);
    return arr[size / 2];
}

int main() {
    FILE *file;
    int n, i;
    
    // Open the file in read mode
    file = fopen("TestCase_05.txt", "r");
    
    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    // Read the number of elements in the array
    fscanf(file, "%d", &n);
    
    //Dynamically allocate memory for an integer array of a particular size
    int *marks = (int*)malloc(n * sizeof(int));

    // Read the elements of the array
    for (i = 0; i < n; i++) {
        fscanf(file, "%d,", &marks[i]);
    }

    // Close the file
    fclose(file);

    // Find the median and print the result
    int median = SelectingTheMedian(marks, n);
    printf("Median: %d\n", median);

    // free dynamically allocated memory
    free(marks);

    return 0;
}

