#include <stdio.h>
#include<stdlib.h>

// Function to find the highest number of consecutive extended working hours
int GoingOffTheCharts(int arr[], int n) {
    int highestConsecutive = 0;
    int consecutive = 0;
	int i;
	
    for (i = 0; i < n; i++) {
        if (arr[i] > 6) {
            consecutive++;
            if (consecutive > highestConsecutive) {
                highestConsecutive = consecutive;
            }
        } else {
            consecutive = 0;
        }
    }

    return highestConsecutive;
}

int main() {
    FILE *file;
    int length,i;

    // Read input from the file
    file = fopen("TestCase_01.txt", "r");
    if (file == NULL) {
        printf("File not found.\n");
        return 1;
    }

    fscanf(file, "%d", &length);

    int array[length];

    for (i = 0; i < length; i++) {
        fscanf(file, "%d", &array[i]);
    }

    fclose(file);

    // Calling the function GoingOffTheCharts
    int result = GoingOffTheCharts(array, length);
    
    printf("Highest consecutive extended working hours: %d\n", result);

    return 0;
}

