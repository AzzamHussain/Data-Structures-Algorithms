#include <stdio.h>
#include <stdlib.h>

// Function to find the index of a number in a text file
int FixingCodeInProduction(int arr[], int size, int num) {
    int left = 0;
    int right = size - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == num)
            return mid;
        else if (arr[mid] < num)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1; //Will return -1 when number is not found
}

int main() {
    FILE *file;
    file = fopen("TestCase_01.txt", "r");

    if (file == NULL) {
        printf("File not found.\n");
        return 1;
    }

    int numToFind, size;
    fscanf(file, "%d", &numToFind);
    fscanf(file, "%d", &size);
	
	//Dynamically allocate memory for an integer array of a particular size
	int *array = (int *)malloc(size * sizeof(int));
    if (array == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }
	int i;
    for (i = 0; i < size; i++) {
        fscanf(file, "%d,", &array[i]);
    }

    fclose(file);

    // Finding the index of the number in the array
    int result = FixingCodeInProduction(array, size, numToFind);


    if (result == -1) {
    	printf("%d does not exist, so -1 will be answer.\n", numToFind);
    } 
	else {
    	printf("%d is at %dth index.\n", numToFind, result);
    }


	//free dynamically allocated memory
	free(array);
	
    return 0;
}

