#include <stdio.h>

// Function to count the number of bribes in the queue
// n = size of the queue (array)
int BribedQueue(int n, int queue[]) {
    int bribes = 0;
    int i;
    for (i = 0; i < n; i++) {
        int key = queue[i];
        int j = i - 1;
        while (j >= 0 && key < queue[j]) {
            queue[j + 1] = queue[j];
            bribes++;
            --j;
        }
        queue[j + 1] = key;
    }
    return bribes;
}

int main() {
    FILE *file;
    int length, i;

    // Open the file in read mode
    file = fopen("TestCase_01.txt", "r");

    if (file == NULL) {
        printf("File not found.\n");
        return 1;
    }

    // Read the length of the array
    fscanf(file, "%d", &length);

	int array[length];
	
    // Read the elements of the array from the file
    for (i = 0; i < length; i++) {
        fscanf(file, "%d", &array[i]);
    }

    // Close the file
    fclose(file);

    // Calling the BribedQueue function
    int num_bribes = BribedQueue(length, array);

    printf("Number of Bribes: %d\n", num_bribes);

    return 0;
}

